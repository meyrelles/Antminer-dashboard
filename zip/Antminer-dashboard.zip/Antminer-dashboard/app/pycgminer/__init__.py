from .pycgminer import CgminerAPI
